# config.py
DATABASE_CONFIG = {
    'server': 'ZACKY\\SQLEXPRESS',
    'database': 'AdminDB',
    'driver': 'ODBC Driver 17 for SQL Server',
    'trusted_connection': 'yes',
}
